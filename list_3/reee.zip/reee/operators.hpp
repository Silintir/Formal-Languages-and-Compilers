#pragma once

int add(int a, int b);
int sub(int a, int b);
int mult(int a, int b);
int divide(int a, int b);
int modulo(int a, int b);
int pwr(int a, int b);
int neg(int a);